#include "BAPBPPacker.h"

BAPBPPacker::BAPBPPacker(BAPPackage& aPackage) : BAPPacker(aPackage) {
}

BAPBPPacker::~BAPBPPacker() {

}


void  BAPBPPacker::WriteSolutionFile(Bool aCompPackWidth) const {

}

void  BAPBPPacker::ReadSolutionFile() {

}

void  BAPBPPacker::Solve() {

}


